# Molgenis
### How to run your own

## Needed extras to fit custom install
- Software components
- Java
- Tomcat
- Apache HTTPD/NGINX
- Minio
- Postgresql
- ElasticSearch

## Requirements
- OS: RedHat 8 or Centos 8 minimal install
- HW specs:  
  - 4-8 Gb memory
  - 2-4 cores
  - 40 Gb diskspace
- ssh access to server with ssh keys (root or unprivileged user)
- Ansibe or AnsibleTower/Ansible AWX

## Ansible
why ansible
how we use it ansible tower, 150 Vms, install patch, upgrade

## Ansible Basic playbook
- sets up basic Molgenis on http.
- Modular setup with Roles
- easily extendable with pre an post roles to setup customer/cloud specifics
  - SSL certs
  - firewall
  - backup
  - monitoring/logging

Needed extras to fit custom install
- SSL tcp/443

## Ansible basic playbook future

## Ansible Galaxy repo
The ansible playbook and roles for a minimum install of Molgenis can be found in http://galaxy.ansible.com/molgenis/molgenis8
The ansible scripts used to install Molgenis in the RUG OpenStack are in a private GitHub repo, but will be adapted in the future to also use the roles provided in the Ansible Galaxy repo.

