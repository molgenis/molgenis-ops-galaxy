The preinstall role installs pre-req RPMs and unlocks the dfn version lock.
