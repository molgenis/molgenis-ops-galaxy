The swap role configures a swap partition for use in Molgenis as it is missing in most cloud os images. You can skip this role if you have more than 16 GB of memory.
