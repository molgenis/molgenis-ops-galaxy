The httpd role installs and configures apache httpd for use as Molgenis frontend
