The python role installs python 3 as required by Molgenis
