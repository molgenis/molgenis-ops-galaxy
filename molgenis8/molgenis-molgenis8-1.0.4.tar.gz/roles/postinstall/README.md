The postinstall role locks the versions of the key components.
