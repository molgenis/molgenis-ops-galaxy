The postgresql_11 role installs and configures postgresql 11  omponent for use in Molgenis
