#!/bin/bash
/bin/rm -f /tmp/import*.log
/bin/rm -f /tmp/filestore_backup_*.tgz
/bin/rm -f /tmp/postgresql*.sql
/bin/rm -rf /usr/local/share/molgenis/data_old
