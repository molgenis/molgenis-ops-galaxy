The molgenis role installs and configures our Molgenis WAR.
