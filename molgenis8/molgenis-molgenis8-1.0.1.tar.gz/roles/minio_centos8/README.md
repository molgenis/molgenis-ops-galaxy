The minio role installs and configures minio component for use in Molgenis
