#!/bin/bash
/bin/chown -R tomcat:molgenis /usr/local/share/molgenis/data
