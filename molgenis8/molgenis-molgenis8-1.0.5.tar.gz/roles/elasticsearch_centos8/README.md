The elasticsearch role installs and configures elastic search component for use in Molgenis
