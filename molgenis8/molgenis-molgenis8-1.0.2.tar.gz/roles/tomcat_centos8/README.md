The tomcat role installs and configures apache tomcat component for use in Molgenis
