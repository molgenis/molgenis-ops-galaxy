The role configures the virtual host with all the unpk frontend components certified for this version of Molgenis backend.
